const mongoose = require('mongoose');

const parkingSchema = new mongoose.Schema({
    parkingLotId: {
        type: String,
        required: true
    },
    registrationNumber: {
        type: String,
        required: true,
        validate: /^[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}$/
    },
    color: {
        type: String,
        required: true,
        enum: ['RED', 'GREEN', 'BLUE', 'BLACK', 'WHITE', 'YELLOW', 'ORANGE']
    },
    status: {
        type: String,
        enum: ['PARKED', 'LEFT'],
        default: 'PARKED'
    },
    slotNumber: {
        type: Number
    }
});

module.exports = mongoose.model('Parking', parkingSchema);
