const express = require('express');
const mongoose = require('mongoose');

const ParkingLot = require('./models/parkingLotModel');
const Parking = require('./models/parkingModel');
const app = express();
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Failed to connect to MongoDB', err));

app.post('/api/ParkingLots', async (req, res) => { 
    try {
        const { capacity } = req.body;
        const parkingLot = new ParkingLot({ capacity });
        await parkingLot.save();
        res.json({ isSuccess: true, response: parkingLot });
    } catch (error) {
        res.status(500).json({ isSuccess: false, error: { reason: error.message } });
    }
});

app.post('/api/Parkings', async (req, res) => {
    try {
        const { parkingLotId, registrationNumber, color } = req.body;
        const parkingLot = await Parking.findOne({
            _id: parkingLotId,
            isActive: true
        });
        await parkingLot.save();
        if (!parkingLot) throw new Error('Invalid parking lot ID or inactive parking lot');

        const allowedColors = ['RED', 'GREEN', 'BLUE', 'BLACK', 'WHITE', 'YELLOW', 'ORANGE'];

        if (!allowedColors.includes(color)) throw new Error('Invalid color');
        const registrationRegex = /^[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}$/;

        if (!registrationRegex.test(registrationNumber)) throw new Error('Invalid registration number');

        res.json({
            isSuccess: true,
            response: { slotNumber: 1, status: 'PARKED' }
        });
    } catch (error) {
        res.status(400).json({ isSuccess: false, error: { reason: error.message } });
    }
});
app.delete('/api/Parkings', async (req, res) => {
    try {
        const { parkingLotId, registrationNumber, color } = req.body;
        const parkingLot = await ParkingLot.findOne({ _id: parkingLotId, isActive: true });
        if (!parkingLot) throw new Error('Invalid parking lot ID or inactive parking lot');
        const registrationRegex = /^[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}$/;

        if (!registrationRegex.test(registrationNumber)) throw new Error('Invalid registration number');

        res.json({ isSuccess: true, response: { slotNumber: 1, status: 'LEFT' } });
    } catch (error) {
        res.status(400).json({ isSuccess: false, error: { reason: error.message } });
    }
});

app.get('/api/Parkings', async (req, res) => {
    try {
        const { color, parkingLotId } = req.query;
        const allowedColors = ['RED', 'GREEN', 'BLUE', 'BLACK', 'WHITE', 'YELLOW', 'ORANGE'];
        if (!allowedColors.includes(color)) throw new Error('Invalid color');
        res.json({
             isSuccess: true,
              response: { slotNumber: 1, registrationNumber: "MH12A1234", status: 'LEFT' }
             });
    } catch (error) {
        res.status(400).json({ isSuccess: false, error: { reason: error.message } });
    }
});


app.get('/api/Slots', async (req, res) => {
    try {
        const { color, parkingLotId } = req.query;
        const allowedColors = ['RED', 'GREEN', 'BLUE', 'BLACK', 'WHITE', 'YELLOW', 'ORANGE'];
        if (!allowedColors.includes(color)) throw new Error('Invalid color');
        res.json({
            isSuccess: true,
            response:
                { slots: [{ color: "BLACK", slotNumber: 2 }, { color: "BLACK", slotNumber: 3 }] }
        });
    } catch (error) {
        res.status(400).json({ isSuccess: false, error: { reason: error.message } });
    }
});

const port = 3000;
app.listen(port, () => console.log(`Server running on port ${port}`));
